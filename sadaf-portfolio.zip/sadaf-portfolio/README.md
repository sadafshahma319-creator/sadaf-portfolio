# Sadaf Shahma: Portfolio

## Run locally
1. Install Node.js (LTS) from nodejs.org
2. In this folder run: `npm install`
3. Then: `npm run dev` and open the address shown (usually http://localhost:5173)

## Replace your information
Everything lives in `src/data/content.js`. Search for `REPLACE` and fix each one: email, GitHub, LinkedIn, BCA college name, MyGate and Cisco details, project contribution and technologies. Only add what is true.

## Add your resume
Save it as `public/resume.pdf` (exact name). The buttons already point to `/resume.pdf`.

## Add project screenshots
Put images in `public/screenshots/` (e.g. `furniture-home.png`), then set `image: '/screenshots/furniture-home.png'` in `content.js`. Add the live link in `demo` and the repo link in `github`. Optional video link goes in `video`.

## Connect to GitHub
1. Create a new repository on github.com (e.g. `portfolio`), empty.
2. In this folder: `git init`, `git add .`, `git commit -m "Initial portfolio"`, `git branch -M main`
3. `git remote add origin https://github.com/YOUR-USERNAME/portfolio.git` then `git push -u origin main`

## Deploy free (Vercel or Netlify)
1. Sign in at vercel.com (or netlify.com) with GitHub.
2. Choose "Add New Project", pick your `portfolio` repo. Settings are auto-detected (build `npm run build`, output `dist`).
3. Click Deploy. You get a live URL like `https://portfolio-yourname.vercel.app`. Put it on your resume and LinkedIn, and in your project's live demo links if relevant.
Every `git push` updates the live site.
