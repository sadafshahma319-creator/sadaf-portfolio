import Navbar from './components/Navbar.jsx'
import Hero from './components/Hero.jsx'
import { About, Education, Skills, Experience, Activities } from './components/Sections.jsx'
import Projects from './components/Projects.jsx'
import Contact from './components/Contact.jsx'
import Footer from './components/Footer.jsx'

export default function App() {
  return (
    <>
      <a href="#about" className="sr-only focus:not-sr-only focus:absolute focus:z-50 focus:bg-white focus:p-2">Skip to content</a>
      <Navbar />
      <main>
        <Hero />
        <About />
        <Education />
        <Skills />
        <Experience />
        <Projects />
        <Activities />
        <Contact />
      </main>
      <Footer />
    </>
  )
}
