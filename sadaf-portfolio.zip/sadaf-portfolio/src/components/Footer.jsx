import { profile } from '../data/content.js'

export default function Footer() {
  return (
    <footer className="bg-ink px-5 py-8 text-center text-sm text-white/70">
      <p>© {new Date().getFullYear()} {profile.name}. Built with React, Vite and Tailwind CSS.</p>
    </footer>
  )
}
