import Reveal from './Reveal.jsx'

export default function Section({ id, title, children, tone = 'light' }) {
  return (
    <section id={id} className={tone === 'dark' ? 'bg-ink text-white' : ''}>
      <div className="mx-auto max-w-5xl px-5 py-20 sm:py-24">
        <Reveal>
          <h2 className="mb-10 text-3xl font-bold tracking-tight sm:text-4xl">{title}</h2>
          {children}
        </Reveal>
      </div>
    </section>
  )
}
