import { useState } from 'react'
import Section from './Section.jsx'
import { profile } from '../data/content.js'

export default function Contact() {
  const [f, setF] = useState({ name: '', email: '', message: '' })
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value })
  // No backend needed: this opens the visitor's email app with the message filled in.
  const send = (e) => {
    e.preventDefault()
    const body = encodeURIComponent(`${f.message}\n\nFrom: ${f.name} (${f.email})`)
    window.location.href = `mailto:${profile.email}?subject=${encodeURIComponent('Portfolio message from ' + f.name)}&body=${body}`
  }
  const field = 'w-full rounded-md border border-line bg-white px-4 py-2.5'
  return (
    <Section id="contact" title="Contact">
      <div className="grid gap-10 md:grid-cols-2">
        <div className="space-y-3">
          <p>Open to entry-level IT, software and data opportunities. Feel free to get in touch.</p>
          <p><a className="font-semibold text-accent underline" href={`mailto:${profile.email}`}>{profile.email}</a></p>
          <p><a className="font-semibold text-accent underline" href={profile.linkedin} target="_blank" rel="noreferrer">LinkedIn</a></p>
          <p><a className="font-semibold text-accent underline" href={profile.github} target="_blank" rel="noreferrer">GitHub</a></p>
        </div>
        <form onSubmit={send} className="space-y-4">
          <div><label htmlFor="n" className="mb-1 block font-semibold">Name</label><input id="n" required className={field} value={f.name} onChange={set('name')} /></div>
          <div><label htmlFor="e" className="mb-1 block font-semibold">Email</label><input id="e" type="email" required className={field} value={f.email} onChange={set('email')} /></div>
          <div><label htmlFor="m" className="mb-1 block font-semibold">Message</label><textarea id="m" rows="4" required className={field} value={f.message} onChange={set('message')} /></div>
          <button className="rounded-md bg-ink px-6 py-3 font-semibold text-white hover:bg-accent">Send message</button>
        </form>
      </div>
    </Section>
  )
}
