import { useState } from 'react'
import { profile } from '../data/content.js'

const links = [['About', 'about'], ['Education', 'education'], ['Skills', 'skills'], ['Experience', 'experience'], ['Projects', 'projects'], ['Contact', 'contact']]

export default function Navbar() {
  const [open, setOpen] = useState(false)
  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b border-line bg-paper/90 backdrop-blur">
      <nav aria-label="Main" className="mx-auto flex max-w-5xl items-center justify-between px-5 py-3">
        <a href="#top" className="font-display text-lg font-extrabold">{profile.name}</a>
        <button className="rounded-md border border-line px-3 py-1 md:hidden" aria-expanded={open} aria-controls="menu" onClick={() => setOpen(!open)}>
          {open ? 'Close' : 'Menu'}
        </button>
        <ul id="menu" className={`${open ? 'flex' : 'hidden'} absolute left-0 right-0 top-full flex-col gap-1 border-b border-line bg-paper p-4 md:static md:flex md:flex-row md:items-center md:gap-6 md:border-0 md:bg-transparent md:p-0`}>
          {links.map(([label, id]) => (
            <li key={id}><a href={`#${id}`} onClick={() => setOpen(false)} className="block py-2 text-sm font-semibold hover:text-accent">{label}</a></li>
          ))}
          <li><a href={profile.resume} download className="block rounded-md bg-ink px-4 py-2 text-sm font-semibold text-white hover:bg-accent">Resume</a></li>
        </ul>
      </nav>
    </header>
  )
}
