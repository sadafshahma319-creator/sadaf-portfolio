import Section from './Section.jsx'
import { project as p } from '../data/content.js'

function LinkButton({ href, label, primary }) {
  const base = 'rounded-md px-5 py-2.5 text-sm font-semibold transition '
  if (!href) return <span className={base + 'cursor-not-allowed border border-dashed border-white/40 text-white/60'} title="Add this link in src/data/content.js">{label} (add link)</span>
  return <a href={href} target="_blank" rel="noreferrer" className={base + (primary ? 'bg-mint text-ink hover:bg-white' : 'border border-white/40 hover:bg-white/10')}>{label}</a>
}

export default function Projects() {
  return (
    <Section id="projects" title="Featured project" tone="dark">
      <article className="grid overflow-hidden rounded-2xl border border-white/15 bg-white/5 md:grid-cols-2">
        {/* PREVIEW: set `image` in src/data/content.js (file goes in public/screenshots/) */}
        <div className="flex min-h-64 items-center justify-center bg-white/10 p-6 text-center text-white/70">
          {p.image ? <img src={p.image} alt={`Screenshot of ${p.title}`} loading="lazy" className="h-full w-full object-cover" /> : <p>Project preview: add a screenshot at public/screenshots/ and set <code>image</code> in content.js</p>}
        </div>
        <div className="space-y-4 p-6 sm:p-8">
          <p className="text-sm text-mint">{p.tag}</p>
          <h3 className="text-2xl font-bold">{p.title}</h3>
          <p className="text-white/80">{p.description}</p>
          <div><h4 className="font-bold">My contribution</h4><p className="text-white/80">{p.contribution}</p></div>
          <div><h4 className="font-bold">Key features</h4><ul className="list-disc pl-5 text-white/80">{p.features.map((f) => <li key={f}>{f}</li>)}</ul></div>
          <div><h4 className="font-bold">Technologies</h4>
            {p.technologies.length ? <ul className="flex flex-wrap gap-2">{p.technologies.map((t) => <li key={t} className="rounded-full bg-white/10 px-3 py-1 text-sm">{t}</li>)}</ul> : <p className="text-white/60">Add the technologies you really used in content.js.</p>}
          </div>
          <div className="flex flex-wrap gap-3 pt-2">
            <LinkButton href={p.demo} label="Live Demo" primary />
            <LinkButton href={p.github} label="GitHub" />
            {p.video && <LinkButton href={p.video} label="Project Video" />}
          </div>
        </div>
      </article>
    </Section>
  )
}
