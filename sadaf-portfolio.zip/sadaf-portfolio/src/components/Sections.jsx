import Section from './Section.jsx'
import { about, education, skills, experience, internship, activities } from '../data/content.js'

export function About() {
  return (
    <Section id="about" title="About me">
      <div className="max-w-2xl space-y-4 text-lg">{about.map((p) => <p key={p}>{p}</p>)}</div>
    </Section>
  )
}

export function Education() {
  return (
    <Section id="education" title="Education">
      <ol className="space-y-6 border-l-2 border-accent pl-6">
        {education.map((e) => (
          <li key={e.title}>
            <h3 className="text-xl font-bold">{e.title}</h3>
            <p>{e.place} · {e.period}</p>
            <p className="text-ink/70">{e.note}</p>
          </li>
        ))}
      </ol>
    </Section>
  )
}

export function Skills() {
  return (
    <Section id="skills" title="Skills">
      <h3 className="mb-3 text-lg font-bold">Strengths</h3>
      <ul className="mb-10 flex flex-wrap gap-2">
        {skills.confirmed.map((s) => <li key={s} className="rounded-full border border-accent bg-white px-4 py-1.5 text-sm font-semibold">{s}</li>)}
      </ul>
      <h3 className="mb-1 text-lg font-bold">Technical skills: add if applicable</h3>
      <p className="mb-3 text-sm text-ink/70">Keep only what you can confidently talk about in an interview, and delete the rest in src/data/content.js.</p>
      <ul className="flex flex-wrap gap-2">
        {skills.addIfApplicable.map((s) => <li key={s} className="rounded-full border border-dashed border-ink/40 px-4 py-1.5 text-sm text-ink/70">{s}</li>)}
      </ul>
    </Section>
  )
}

function Role({ data }) {
  return (
    <article className="rounded-xl border border-line bg-white p-6">
      <h3 className="text-xl font-bold">{data.title}, {data.place}</h3>
      <p className="mb-3 text-accent">{data.period}</p>
      <ul className="list-disc space-y-1 pl-5">{data.points.map((p) => <li key={p}>{p}</li>)}</ul>
    </article>
  )
}

export function Experience() {
  return (
    <Section id="experience" title="Experience and internship">
      <div className="grid gap-6 md:grid-cols-2"><Role data={experience} /><Role data={internship} /></div>
    </Section>
  )
}

export function Activities() {
  return (
    <Section id="activities" title="Activities">
      <div className="grid gap-6 md:grid-cols-2">
        {activities.map((a) => (
          <article key={a.title} className="rounded-xl border border-line bg-white p-6">
            <h3 className="text-lg font-bold">{a.title}</h3><p>{a.text}</p>
          </article>
        ))}
      </div>
      <p className="mt-6 text-sm text-ink/70">Certifications: none listed yet. Add any real certificates here later.</p>
    </Section>
  )
}
