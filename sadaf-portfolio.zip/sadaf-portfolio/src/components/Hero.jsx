import { profile } from '../data/content.js'

export default function Hero() {
  return (
    <section id="top" className="bg-ink text-white">
      <div className="mx-auto grid min-h-screen max-w-5xl content-center gap-6 px-5 pb-16 pt-28">
        <p className="rise text-mint" style={{ animationDelay: '0s' }}>Hello, I am</p>
        <h1 className="rise text-5xl font-extrabold leading-tight tracking-tight sm:text-7xl" style={{ animationDelay: '.1s' }}>{profile.name}</h1>
        <p className="rise font-display text-xl text-mint sm:text-2xl" style={{ animationDelay: '.2s' }}>{profile.role}</p>
        <p className="rise max-w-xl text-lg text-white/80" style={{ animationDelay: '.3s' }}>{profile.intro}</p>
        <div className="rise mt-4 flex flex-wrap gap-3" style={{ animationDelay: '.4s' }}>
          <a href="#projects" className="rounded-md bg-mint px-6 py-3 font-semibold text-ink transition hover:bg-white">View My Projects</a>
          <a href={profile.resume} download className="rounded-md border border-white/40 px-6 py-3 font-semibold transition hover:bg-white/10">Download Resume</a>
        </div>
        <div className="rise flex gap-5 text-sm" style={{ animationDelay: '.5s' }}>
          <a className="underline underline-offset-4 hover:text-mint" href={profile.github} target="_blank" rel="noreferrer">GitHub</a>
          <a className="underline underline-offset-4 hover:text-mint" href={profile.linkedin} target="_blank" rel="noreferrer">LinkedIn</a>
        </div>
      </div>
    </section>
  )
}
