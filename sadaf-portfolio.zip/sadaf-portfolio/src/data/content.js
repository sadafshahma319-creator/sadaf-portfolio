// ============================================================
// EDIT THIS FILE to change what appears on your website.
// Anything marked REPLACE is a placeholder, not real information.
// ============================================================

export const profile = {
  name: 'Sadaf Shahma',
  role: 'MCA Student | Aspiring IT Professional',
  intro:
    'I am an MCA student at Kalinga University, preparing for entry-level IT, software and data roles. I enjoy building practical projects and learning by doing.',
  email: 'your-email@example.com', // REPLACE with your real email
  github: 'https://github.com/YOUR-USERNAME', // REPLACE with your GitHub profile URL
  linkedin: 'https://www.linkedin.com/in/YOUR-PROFILE', // REPLACE with your LinkedIn URL
  resume: '/resume.pdf', // Put your file at public/resume.pdf
}

export const about = [
  'I am pursuing my MCA at Kalinga University (2027) after completing a Bachelor of Computer Applications (BCA). I am a fresher looking for an entry-level opportunity in IT, software or data.',
  'My BCA final-year project was a furniture e-commerce website built with a teammate. Outside academics, I worked as a Business Development Executive at MyGate, completed a Cisco internship, and took part in college volunteering and anchoring.',
  'I like solving problems, working with others, and turning what I learn into practical projects.',
]

export const education = [
  { title: 'Master of Computer Applications (MCA)', place: 'Kalinga University', period: 'Expected 2027', note: 'Currently pursuing' },
  { title: 'Bachelor of Computer Applications (BCA)', place: 'REPLACE: college / university name', period: 'REPLACE: years', note: 'Final-year project: E-Commerce Furniture Website' },
]

// "confirmed" skills come from your background. "addIfApplicable" are suggestions: keep only what is true for you.
export const skills = {
  confirmed: [
    'Problem-solving',
    'Teamwork (built BCA project with a teammate)',
    'Communication and public speaking (college anchoring)',
    'Client-facing business development (MyGate)',
    'Volunteering and reliability',
    'Web development fundamentals (BCA project)',
  ],
  addIfApplicable: ['HTML', 'CSS', 'JavaScript', 'SQL', 'Python', 'Java', 'Git and GitHub', 'MS Excel', 'Networking basics (Cisco)'],
}

export const experience = {
  title: 'Business Development Executive',
  place: 'MyGate',
  period: 'August 2025 – December 2025 (4 months)',
  points: [
    'Worked in a business development role at MyGate for four months.',
    'REPLACE: add 2–3 things you actually did (e.g. client outreach, product demos, follow-ups). Keep them true and specific.',
  ],
}

export const internship = {
  title: 'Cisco Internship',
  place: 'Cisco',
  period: '2025',
  points: [
    'Completed an internship with Cisco in 2025.',
    'REPLACE: add the program name, topics covered and what you learned. Do not add anything you did not do.',
  ],
}

export const project = {
  title: 'E-Commerce Furniture Website',
  tag: 'BCA final-year project, built with a teammate',
  description:
    'A modern furniture e-commerce website focused on attractive product presentation, clear product prices, user-friendly navigation and a simple shopping experience.',
  contribution: 'REPLACE: describe exactly which parts you built (e.g. pages, design, testing). Be specific and honest.',
  features: ['Attractive product presentation', 'Product prices shown clearly', 'User-friendly navigation', 'Simple shopping experience'],
  technologies: [], // REPLACE: add only technologies you really used, e.g. ['HTML', 'CSS', 'JavaScript']
  github: '', // REPLACE: paste GitHub repo URL (leave '' to show a placeholder button)
  demo: '', // REPLACE: paste live demo URL (leave '' to show a placeholder button)
  image: '', // REPLACE: e.g. '/screenshots/furniture-home.png' (file in public/screenshots)
  video: '', // OPTIONAL: e.g. a YouTube link to a demo video
}

export const activities = [
  { title: 'College volunteer activities', text: 'Volunteered in college events and activities.' },
  { title: 'College anchoring', text: 'Participated in college anchoring, which built my confidence in speaking and communication.' },
]
